package proyectofinal.helpme;

/**
 * Created by Ilanit Jamilis on 14/7/2017.
 */

public class Denuncia {
    int id;
    double latitud;
    double longitud;
    String descripcion;
    String tipo;
}
