package proyectofinal.helpme;

/**
 * Created by Ilanit Jamilis on 19/5/2017.
 */

public class utilidades {

    public static String miCodigoPais = "";
}
