package proyectofinal.helpme;


public class Pais {

    String codigoP;
    Integer numPoliciaP;
    Integer numAmbulanciaP;
    Integer numBomberosP;
}
